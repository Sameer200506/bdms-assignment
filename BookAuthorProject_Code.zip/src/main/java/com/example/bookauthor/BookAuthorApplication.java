
package com.example.bookauthor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookAuthorApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookAuthorApplication.class, args);
    }
}
